-- PAIR CONSENT: initial schema sketch only.
-- Review and harden before production. Do not deploy as-is.
create extension if not exists pgcrypto;

create table if not exists public.sessions (
  id uuid primary key default gen_random_uuid(),
  invite_token_hash text not null unique,
  label text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 days'),
  status text not null default 'open' check (status in ('open','closed','expired'))
);

create table if not exists public.participant_responses (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.sessions(id) on delete cascade,
  participant_slot text not null check (participant_slot in ('A','B')),
  pre_answers jsonb not null default '[]'::jsonb,
  pre_confirmed_at timestamptz,
  post_answers jsonb,
  post_confirmed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(session_id, participant_slot)
);

-- IMPORTANT:
-- Do not enable anonymous direct table writes from the browser.
-- Production writes should go through server-side Edge Functions that:
-- 1) validate a high-entropy invite token,
-- 2) enforce one participant slot per scoped participant capability,
-- 3) prevent A from modifying B and vice versa,
-- 4) reject all writes after expires_at,
-- 5) avoid logging raw tokens or sensitive response content.
-- Keep service-role credentials server-side only.

-- Schedule a server-side cleanup job in production after enabling pg_cron.
-- Example SQL (adapt and test in the target project):
-- select cron.schedule(
--   'pair-consent-delete-expired',
--   '17 * * * *',
--   $$delete from public.sessions where expires_at <= now();$$
-- );
-- ON DELETE CASCADE removes participant responses.
